import React from 'react';
import { useState } from 'react';
import './App.css';


const Add = () => {
  const [text, setText] = useState("");
  const [output, setOutput] = useState(0);

 function subtraction() {
   setOutput(-20 + Number(text));
  }
  function addition() {
    setOutput(20 + Number(text));
  }
  function clear() {
    setOutput(0);
  }
  function valueOnChange(event) {
    setText(event.target.value);
  }

  return (
    <main>
      <h1> Add-Sub react</h1>
      <input
        type="Number"
        placeholder="Enter the number for add and subtract"
        onChange={valueOnChange}
        value={text}
      />

      <button onClick={addition}>add</button>
      <button onClick={subtraction}>sub</button>
      <button onClick={clear}>clear</button>

      <div>
        <span>Result</span>
        <div id="Result">{output}</div>
      </div>
    </main>

  );
};
export default Add;